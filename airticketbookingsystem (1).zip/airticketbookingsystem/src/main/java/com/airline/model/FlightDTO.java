package com.airline.model;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import com.airline.entity.Airline;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class FlightDTO {
	
	private int flight_id;
	@NotNull(message = "avilable seat can not be null")
	private int availableSeats;
	@NotNull(message = "total seat can not be null")
	private int totalSeats;
	@NotNull(message = "traveller class can not be null")
	private String travellerClass;
	@NotNull(message = "time can not be null")
	private String time;
	@NotNull(message = "date can not be null")
	private LocalDate date;
	@NotNull(message = "sourcecan not be null")
	private String source;
	@NotNull(message = "destination can not be null")
	private String destination;
	
	private Airline airline;

}
