package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Admin;
import com.airline.entity.Airline;
import com.airline.entity.Passenger;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.AdminDTO;
import com.airline.model.PassengerDTO;
import com.airline.repository.AdminRepository;
import com.airline.service.AdminService;
import com.airline.util.Converter;
@Service
public class AdminServiceImpl implements AdminService{
	//logger statistically created
		private static final Logger l = LoggerFactory.getLogger(AdminService.class);
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private Converter converter;
	//for create admin in ServiceImpl
	@Override
	public AdminDTO createAdmin(Admin admin) {
		admin.setUserName(admin.getUserName());
		admin.setPassword(admin.getPassword());
		admin.setRole(admin.getRole());
		
		adminRepository.save(admin);
		l.info("Admin "+admin.toString()+" added at "+new Date());
		
		return converter.convertToAdminDTO(admin);
	}
//for update admin by id in ServiceImpl
	@Override
	public AdminDTO updateAdmin(int id, Admin admin) {

		//we need to check wheather Admin with given exist in DB or not
				Admin existingAdmin=adminRepository.findById(id).orElseThrow(()->
				new ResourceNotFoundException("Admin", "id", id));
				//we will get data from client and set in existing Admin
				existingAdmin.setAdminName(admin.getAdminName());
				existingAdmin.setEmail(admin.getEmail());
				existingAdmin.setUserName(admin.getUserName());
				existingAdmin.setPassword(admin.getPassword());
				existingAdmin.setRole(admin.getRole());
			adminRepository.save(existingAdmin);
			l.info("Admin with id "+ id +" updated at "+new Date());
			return converter.convertToAdminDTO(existingAdmin);
	}
// for fetch admin by id in ServiceImpl
	@Override
	public AdminDTO getAdminById(int id) {

		Admin admin=adminRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Admin", "id", id));
		l.info("Getting admin details of "+id+" at "+new Date());
		return converter.convertToAdminDTO(admin);
	}
// for fetch all admin in ServiceImpl
	@Override
	public List<AdminDTO> getAllAdmin() {
		List<Admin>	 admins=adminRepository.findAll();
		l.info("Getting all admin details at "+ new Date());
		List<AdminDTO> adminsDTO=new ArrayList<>();
		for(Admin ad: admins)
		{
			adminsDTO.add(converter.convertToAdminDTO(ad));
		}
			return adminsDTO;
		}
// for delete admin by id in ServiceImpl
	@Override
	public String deleteAdminById(int id) {
		
		String msg=null;
		Optional<Admin> opPass=adminRepository.findById(id);
		if(opPass.isPresent())
		{
			adminRepository.deleteById(id);
			
			msg="record deleted successfully";
		}
		else {
			throw new ResourceNotFoundException("Admin", "id", id);
		}
		l.info("Deleting admin details with id" +id+ " at "+new Date());
		return msg;
			
		}
	}
	


