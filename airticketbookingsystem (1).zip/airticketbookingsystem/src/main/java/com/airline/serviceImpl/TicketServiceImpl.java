package com.airline.serviceImpl;

import java.time.LocalDate;
import java.util.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.entity.TicketBooking;
import com.airline.entity.TicketGenerationPdf;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.TicketBookingDTO;
import com.airline.repository.FlightRepository;
import com.airline.repository.PassengerRepository;
import com.airline.repository.TicketBookingRepository;
import com.airline.service.PassengerService;
import com.airline.service.TicketService;
import com.airline.util.TicketConverter;
@Service
public class TicketServiceImpl implements TicketService{
	private static final Logger l=LoggerFactory.getLogger(TicketService.class);
	@Autowired
TicketBookingRepository ticketBookingRepository;
	@Autowired
	TicketConverter ticketConverter;
	@Autowired
FlightRepository flightRepository;
	@Autowired
	PassengerRepository passengerRepository;
	@Autowired
	TicketGenerationPdf ticketGenerationPdf;
	//method used to book a flight and generate a ticket
	@Override
	public String bookFlight(int fid,int pid, TicketBooking ticketBooking) {
		String message=null; 
		Flight flight =flightRepository.findById(fid).get();
		 Passenger passenger= passengerRepository.findById(pid).get();
		   if(flight.getSource().equals(ticketBooking.getSource()) &&
				   flight.getDestination().equals(ticketBooking.getDestination()))
		   {
			   LocalDate fDate=flight.getDate();
			   LocalDate bookingDate=LocalDate.now();
			   if(!bookingDate.isAfter(fDate))
			   {
				   int total_Seat = flight.getAvailableSeats()- ticketBooking.getNo_of_passenger();
				   flight.setAvailableSeats(total_Seat);
		  
				   ticketBooking.setTotalFare(flight.getAirline().getFare()*
				   ticketBooking.getNo_of_passenger());

	

				   ticketBooking.setDestination(ticketBooking.getDestination()); 
				   ticketBooking.setFId(flight);
				   ticketBooking.setPId(passenger);
				   ticketBooking.setAId(ticketBooking.getFId().getAirline());
				   TicketBooking booked=ticketBookingRepository.save(ticketBooking);
		   
		   if(booked!=null)
			   message="Ticket has booked successfully";
		   ticketGenerationPdf.TicketGeneration(booked);
		   }
			   else {
				   message="you have to book before travel date";
			   }
		   }
		   else
			   message="Please enter correct source and destination!!!";
		   l.info("Passenger is booking a flight at "+new Date());
		return message;
		   }
	//method used to cancel the pre-booked flights
	@Override
	public String cancelBooking(int id) {
		String msg=null;
		Optional<TicketBooking> ticket = ticketBookingRepository.findById(id);
		if(ticket.isPresent())
		{
			int nop = ticket.get().getNo_of_passenger();
			ticket.get().getFId().setAvailableSeats((ticket.get().getFId().getAvailableSeats() + nop));
			ticketBookingRepository.deleteById(id);
			msg="Your booking is cancelled!!";
		}
		else
			throw new ResourceNotFoundException("Ticket", "id", id);
		l.info("Passenger cancel booking  flight at "+new Date());
		return msg;
	}
	//method used to get the details of a ticket by using id
		@Override
		public TicketBookingDTO getDistinctByTicketId(int id) {
			TicketBooking ticket = ticketBookingRepository.getDistinctByTicketId(id);
			l.info("Getting ticket details using distinct keyword for unique id at "+new Date());
			return ticketConverter.convertToTicketBookingDTO(ticket);
		}
	}


