package com.airline.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.airline.entity.Passenger;
import com.airline.model.PassengerDTO;

public interface PassengerRepository extends JpaRepository<Passenger, Integer>{
	@Query("select p from Passenger p where p.name=?1")
	List<Passenger>getPassengerByName(String Name);
//	@Query("select p from Passenger p where p.email=?1")
//	Passenger getPassengerByEmail(String email);
	@Query("select p from Passenger p where p.email=:e")
	public Passenger getPassengerByEmail(@Param("e") String email);
}
