package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.airline.entity.TicketBooking;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TicketRepositoryTest {

	@Autowired
	TicketBookingRepository ticketBookingRepository;
	
	
	@Test
	void bookFlightTest()
	{
		TicketBooking ticket = TicketBooking.builder().no_of_passenger(2).Date(LocalDate.now()).
				source("durgapur").destination("pune").build();
		TicketBooking t = ticketBookingRepository.save(ticket);
		assertEquals(t.getNo_of_passenger(), 2);
		
	}
	
	@Test
	@DisplayName("Negative Test Case")
	void cancelFlight() {
		TicketBooking ticket = TicketBooking.builder().no_of_passenger(2).Date(LocalDate.now()).
				source("durgapur").destination("pune").build();
		Optional<TicketBooking> opt= Optional.of(ticket);
		assertThat(opt.get().getSource()).isEqualTo("pune");
	}
}
